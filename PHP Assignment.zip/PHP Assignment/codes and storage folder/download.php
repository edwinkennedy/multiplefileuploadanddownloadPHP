<?php 

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome to Download.</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css" >
</head>
<body>
<div style="margin:30px 30px;">
		<form action="" method="POST">
      <h2>The List Of Uploaded Files.</h2>
   <table class="table" style="margin-bottom:30px;">
   	<tr class="bg-dark" style="color:white;">
   		<th>Select</th>
   		<th>File Names</th>
   	</tr>
   	<?php

class Download{
  public $dbh;

private $host="localhost";
private $user="root";
private $password="";
private $dbnamee="ud";

public function __construct()

{
    $this->dbh=new PDO("mysql:host=$this->host;dbname=$this->dbnamee",$this->user,$this->password);
  

 
   	$sql="select * from fileupp";
	
	$query=$this->dbh->prepare($sql);
	
	$query->execute();
	
	

	while ($result=$query->fetch(PDO::FETCH_ASSOC)) {
		
	
	 ?>
   	<tr>
   		<td>
   			<input type="checkbox" name="files[]" value="<?php echo $result['filename']; ?>" style="width:20px;height:20px;">
   			     
   		</td>
   		<td>
   			<?php echo $result['filename']; ?>
   		</td>
   		
   	</tr>

   	<?php 
   	}

   	 ?>
   	 </table>
   	 <button class="btn btn-primary" name="zipped"> Download Selected Files in a Zipped Folder</button>
   	</form>
</body>
</html>


<?php 
}
  public function downloading()
  {
    if (isset($_POST['zipped'])) {

  $file_folder="uploaded/";
  if (extension_loaded('zip')) {

    if (isset($_POST['files'])&& count($_POST['files'])>0) {
    
          $zip= new ZipArchive();//Loading the zipping Library
          $zipped_name= time().".zip";//zipped name
          echo count($_POST['files']);
          

          

          if ($zip->open($zipped_name,ZIPARCHIVE::CREATE)) {
            
         foreach ($_POST['files'] as $file) {
            $zip->addFile($file_folder.$file);
          }
           
        $zip->close();

          }
          
          
          if (file_exists($zipped_name)) {
            header('Content-type:application/zip');
            header('Content_Disposition:attachment;filename="'.$zipped_name.'"');
            header("Content-Length: ".filesize($zipped_name)); 
            header("Cache-Control: must-revalidate"); 
            readfile($zipped_name);
            //remove zipped file if exists in temp path
            //unlink($zipped_name);
            
          }
          

    }
    else{
      ?>
          <script type="text/javascript">
            alert(" Please First Select Files You Wish To Zip and Download")
          </script>
          <?php
    }
    
  }
  
 }

  }
}	

$obj2= new Download();
$obj2->downloading();

 
 ?>