
<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">

</head>
<body class="bg-light" style="font-family: Agency FB;">
      
                   <div class="container bg-info" style="margin-top: 20px; border-radius:10px;">
                  <div class="row">
                    <h2 style="text-align: center;margin-bottom:20px;font-size:40px;">Welcome To Multiple Upload and Multiple Download System.</h2>
                    <p style="font-weight:bold;font-size:20px;">This Simple System allows You To Upload and Download Multiple Files at  One Click.

                     Due To the Instructions Provided in the Question Saying the Form Validation is Very Important.
                     we have set the Limit size of File to be Uploaded as 400 kylobytes and File Extention Types Allowed are .doc,.ppt,.png,.jpg. And the Download Option You First Select The Files You wish To Download and Then They are zipped in One Folder. this Folder is Placed in Downloads and also its Stored in Parent Folder with Time as Folder Name.  Thank You.

                   </p>
                    <div class="col-sm-6" style="margin-top:35px;">
                        <?php
                        include_once 'upload.php'; 
                        ?>  
                    </div>
                    <div class="col-sm-6">
                        <?php 
                              include_once "download.php"
                        ?>   
                    </div>
                  </div> 
                  </div>   
</body>
</html>