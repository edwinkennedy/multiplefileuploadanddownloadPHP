
<!DOCTYPE html>
<html>
<head>
	<title>Uploading</title>
	<link rel="stylesheet" type="text/css" href="../Bootstrap/css/bootstrap.min.css">

</head>
<body>
  <form class="form" enctype="multipart/form-data" style="margin:auto; margin-bottom:8em; margin-left:20px;" method="POST">
      	<h3>Use This Form To Upload Files.</h3>
        <input type="file" name="file[]" multiple>
        <button class="btn btn-success" name="upload">Upload</button>
      </form>
</body>
</html>


<?php 
class Upload{
	public $dbh;

private $host="localhost";
private $user="root";
private $password="";
private $dbnamee="ud";

public function __construct()

{
    $this->dbh=new PDO("mysql:host=$this->host;dbname=$this->dbnamee",$this->user,$this->password);
  
}

	public $filenumber;
	public $filename;
	public function uploading()
	{
		if (isset($_POST['upload'])) {
	$this->filenumber=count($_FILES['file']['name']);
	for($i=0;$i<$this->filenumber;$i++){
		    $this->filename=$_FILES['file']['name'][$i];

			$allowed = array('doc','png', 'jpg','ppt','docx');
			$extention = pathinfo($this->filename, PATHINFO_EXTENSION);
			

      if (!in_array($extention, $allowed)) {
			    echo 'Bad File Extention'."<br>";
			}
		
        else{
        	if ($_FILES["file"]["size"][$i] > 400000) {
         echo "There is a File That Exceeds the Limit."."<br>";
         
        }
			else{




		$sql="insert into fileupp values (:id,:filename)";
     $id=0;
	$query=$this->dbh->prepare($sql);
	$query->bindParam(':id',$id,PDO::PARAM_INT);
	
	$query->bindParam(':filename',$this->filename,PDO::PARAM_STR);
	

	$result=$query->execute();
	$lastInserted=$this->dbh->lastInsertId();
	if(move_uploaded_file($_FILES['file']['tmp_name'][$i],'uploaded/'.$this->filename)){
		

			echo $_FILES['file']['name'][$i]." were Uploaded Successful"."<br>";
		
	}
	
	else{
		echo "Failed to Upload Files";

	}
   }
	}
	
}
}


	}
	}
$obj= new Upload();
$obj->uploading();

 ?>
