Group 13
-----------

This Assignment Comprises the OOP scripting codes for Multiple Uploads and Multiple Downloads

* Folder " Uploaded"
---------------------

This Folder is the storage folder of uploaded files it must be in the same folder with these files containing the PHP Scripts

*fileupp
-----------

the exported database is in fileupp.sql
and the database name is ud

* members
----------

this word document contains information of group members

*assignment 
-------------
this file holds the problem of our Group.

